﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Numerics;

//---------------------------------------------------
//Yurii Boiko
//011539530
//Notepad App
//
//This application acts like a normal Notepad
//It provides 4 applications:
//Application 1: Load any .txt file
//Application 2: Load the first 50 fibonacci numbers 
//Application 3: Load the first 100 fibonacci numbers
//Application 4: Save the .txt file
//----------------------------------------------------


namespace NotepadApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        //LoadText is a method that takes System.IO.TextReader object as a parameter and
        //puts it in the text box in the interface
        private void LoadText(TextReader sr)
        {
            textBox1.Clear();
            if (sr != null)
            {
                textBox1.Text = sr.ReadToEnd();
            }

        }

        //loadFromFileToolStripMenuItem_Click is a method that allows you to load text from
        //only a text file
        private void loadFromFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog();

            //property that allows only txt files to be loaded
            fileDialog.Filter = "Text|*.txt";

            if (fileDialog.ShowDialog()==DialogResult.OK)
            {
                try
                {
                    using (StreamReader sr = new StreamReader(fileDialog.FileName))
                    {
                        LoadText(sr);
                    }
                    //Renames the title to the name of the file that was opened
                    this.Text= Path.GetFileNameWithoutExtension(fileDialog.FileName);
                }
                //Throws an exeption is file couldn't be read
                catch
                {
                    MessageBox.Show("Error: Could read from the file...");
                }
            }
        }

        //saveFileToolStripMenuItem_Click is a method that you to save whatever is in the textbox
        //to a .txt file 
        private void saveFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFile = new SaveFileDialog();

            //allows only txt files to be save
            saveFile.Filter = "Text|*.txt";

            if (saveFile.ShowDialog()==DialogResult.OK)
            {
                //creates a file stream and textwrite which writes whatever is in the textbox to the file
                using (FileStream fs = new FileStream(saveFile.FileName, FileMode.Create))
                {

                    using(TextWriter tw = new StreamWriter(fs))
                    {
                        tw.Write(textBox1.Text);
                    }
                }
                //Renames the windows form to the file name that was saved
               this.Text = Path.GetFileNameWithoutExtension(saveFile.FileName);
            }
        }

        //loadFibonacciNumbersfirst50ToolStripMenuItem_Click is a method that writes the first 50
        //of the fibonacci numbers by creating FibonacciTextReader object that returns a string 
        private void loadFibonacciNumbersfirst50ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            FibonacciTextReader fc = new FibonacciTextReader(50);
            textBox1.Text = fc.ReadToEnd();
            this.Text = "The first 50 of Fibonacci numbers";
        }

        //loadFibonacciNumbersfirst100ToolStripMenuItem_Click is a method that writes the first 100
        //of the fibonacci numbers by creating FibonacciTextReader object that returns a string 
        private void loadFibonacciNumbersfirst100ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            FibonacciTextReader fc = new FibonacciTextReader(100);
            textBox1.Text = fc.ReadToEnd();
            this.Text = "The first 100 of Fibonacci numbers";
        }
    }

    //FibonacciTextReader is a class that inherits from the System.IO.TextReader
    //which calculates certain user given number fibonacci numbers
    public class FibonacciTextReader : TextReader
    {
        //variables 
        int maxNumber=2, count=1;     //maxNumber is the number of fibonacci numbers the user wants and count is used to keep track
        BigInteger last, secondlast;   //the last to 2 fibonacci numbers
        StringBuilder fibNumbers = new StringBuilder();     //building a string of all the fibonacci numbers

        //Constructer with the given max number of fiboncci number requested
        public FibonacciTextReader(int max)
        {
            maxNumber = max;
        }

        //ReadLine is an override method that calculates the next fibonacci number
        public override string ReadLine()
        {
            
            if (count == 1) {
                secondlast=1;
                count++;
                return 1.ToString();
            }
            else if (count==2) {
                last = 1;
                count++;
                return 1.ToString();
            }
            else{
                BigInteger next = last + secondlast;
                secondlast = last;
                last = next;
                count++;
                return next.ToString();
            }
        }

        //ReadToEnd is override method which appends the the fibonacci numbers
        //that are calculated form the ReadLine function above
        public override string ReadToEnd()
        {

            while (count <= maxNumber)
            {
                fibNumbers.Append(count).Append(": ").Append(ReadLine()).AppendLine();
            }
            return fibNumbers.ToString();
        }
    }
}
